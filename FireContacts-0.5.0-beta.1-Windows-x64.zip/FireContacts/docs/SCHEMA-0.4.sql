-- DDL schema 10. Database identity metadata is populated by FireContacts.

CREATE TABLE contacts(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 uid TEXT NOT NULL UNIQUE CHECK(length(trim(uid))>0),
 designation TEXT NOT NULL DEFAULT '', first_name TEXT NOT NULL DEFAULT '', last_name TEXT NOT NULL DEFAULT '',
 patronymic TEXT NOT NULL DEFAULT '', role TEXT NOT NULL DEFAULT '', organization TEXT NOT NULL DEFAULT '',
 unit TEXT NOT NULL DEFAULT '', county TEXT NOT NULL DEFAULT '', municipality TEXT NOT NULL DEFAULT '',
 area TEXT NOT NULL DEFAULT '', postal_code TEXT NOT NULL DEFAULT '', country TEXT NOT NULL DEFAULT '',
 address TEXT NOT NULL DEFAULT '', email TEXT NOT NULL DEFAULT '', registry_number TEXT NOT NULL DEFAULT '',
 notes TEXT NOT NULL DEFAULT '', search_text TEXT NOT NULL DEFAULT '',
 source_system TEXT NOT NULL DEFAULT '', external_id TEXT NOT NULL DEFAULT '',
 is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN (0,1)),
 pin_priority INTEGER NOT NULL DEFAULT 0 CHECK(pin_priority BETWEEN 0 AND 20 AND (is_active=1 OR pin_priority=0)),
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
 CHECK(length(trim(designation || first_name || last_name))>0),
 CHECK((source_system='' AND external_id='') OR (source_system<>'' AND external_id<>'')));
CREATE UNIQUE INDEX contact_external_identity ON contacts(source_system,external_id) WHERE external_id<>'';
CREATE TRIGGER contact_uid_immutable BEFORE UPDATE OF uid ON contacts WHEN NEW.uid<>OLD.uid
BEGIN SELECT RAISE(ABORT,'Contact UID is immutable'); END;
CREATE INDEX contact_registry ON contacts(organization,registry_number);
CREATE INDEX contact_pin_priority ON contacts(pin_priority) WHERE is_active=1 AND pin_priority>0;
CREATE TABLE phones(id INTEGER PRIMARY KEY, contact_id INTEGER NOT NULL REFERENCES contacts(id) ON DELETE CASCADE,
 label TEXT NOT NULL DEFAULT '', phone_number TEXT NOT NULL CHECK(length(trim(phone_number))>0),
 normalized_phone TEXT NOT NULL DEFAULT '', priority INTEGER NOT NULL DEFAULT 0,
 slot TEXT NOT NULL DEFAULT 'other' CHECK(slot IN ('mobile1','mobile2','landline','other')),
 kind TEXT NOT NULL DEFAULT 'phone' CHECK(kind IN ('phone','email','fax','extension','text')),
 CHECK(slot='other' OR kind='phone'));
CREATE UNIQUE INDEX phone_fixed_slot ON phones(contact_id,slot) WHERE slot<>'other';
CREATE INDEX phone_contact ON phones(contact_id);
CREATE INDEX phone_number ON phones(normalized_phone) WHERE normalized_phone<>'';
CREATE TABLE tags(id INTEGER PRIMARY KEY,name TEXT NOT NULL UNIQUE);
CREATE TABLE contact_tags(contact_id INTEGER NOT NULL REFERENCES contacts(id) ON DELETE CASCADE,tag_id INTEGER NOT NULL REFERENCES tags(id) ON DELETE CASCADE,PRIMARY KEY(contact_id,tag_id));
CREATE TABLE aliases(id INTEGER PRIMARY KEY,contact_id INTEGER NOT NULL REFERENCES contacts(id) ON DELETE CASCADE,alias TEXT NOT NULL);
CREATE INDEX alias_contact ON aliases(contact_id);
CREATE TABLE audit_log(id INTEGER PRIMARY KEY,action TEXT NOT NULL,entity_type TEXT NOT NULL,entity_id INTEGER,details TEXT,machine_name TEXT,windows_user TEXT,created_at TEXT NOT NULL);
CREATE TABLE metadata(key TEXT PRIMARY KEY,value TEXT);
PRAGMA user_version=10;
