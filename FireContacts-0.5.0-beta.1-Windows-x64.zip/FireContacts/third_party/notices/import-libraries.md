# Native XLSX and draft XML support

Statically linked, no runtime download or Excel installation required.

- miniz 3.1.2: official release https://github.com/richgel999/miniz/releases/tag/3.1.2 (amalgamated miniz.c and miniz.h).
- pugixml 1.16: official tag https://github.com/zeux/pugixml/tree/v1.16/src (pugixml.cpp, pugixml.hpp, pugiconfig.hpp).
- License texts: `miniz-LICENSE.txt` and `pugixml-LICENSE.md` in this directory.

SHA-256 of vendored source files:

```
E2C1AEB66EEF9191D8C3FEB164DB2DEF2335A61D039BF04ED849F6B042433B30  miniz.c
B53B62ED122E559B8F679E3CB787A0B0035FE87A58F909DA0E44931678F4E85F  miniz.h
BD94CD9EC6AC67C0723422640BB243EAB4A7C2D9FD5584DAB77305A50FA31EF4  pugixml.cpp
0B7C94701DF3D50981FFAFE57F177C77B940E347C6E5D01073E4161F61299212  pugixml.hpp
E6C51FBC9A765608BD214EA47D229D3BBD6B650036CDFFC94B96B498C202495C  pugiconfig.hpp
```
