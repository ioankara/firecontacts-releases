# SQLite 3.53.4

Official amalgamation downloaded from https://www.sqlite.org/2026/sqlite-amalgamation-3530400.zip

The archive SHA3-256 was verified against the official SQLite download page:

`628a44cfe82c66aed1ccbbe85a562d2e33ebe64b3288981ed76285612227934e`

SHA-256: `1e71ddf93849c6a6ecf58b827c0692073d2dd7ee40196158068f7b29f422e87d`

SQLite is public domain: https://www.sqlite.org/copyright.html

Only sqlite3.c and sqlite3.h are compiled into FireContacts. Loadable extensions are disabled.
